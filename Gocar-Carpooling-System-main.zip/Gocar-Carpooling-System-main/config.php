<?php

$conn = mysqli_connect('localhost','root','','user_db1') or die('connection failed');

?>