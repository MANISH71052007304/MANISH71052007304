# Gocar-Carpooling-System
carpooling system in PHP
# Landing Page
Our Landing page will designed and developed in Reactjs.

![image](https://github.com/raghulvj01/Gocar-Carpooling-System/assets/69421772/45c0cb43-629f-4d34-88b2-86fcda646345)
![image](https://github.com/raghulvj01/Gocar-Carpooling-System/assets/69421772/45899336-d35b-4af9-a2f6-d463f17a3b2c)
![image](https://github.com/raghulvj01/Gocar-Carpooling-System/assets/69421772/3e52882f-aa15-4a6a-938b-86ef048dcefa)
Mobile view of an navigation Menu:

![image](https://github.com/raghulvj01/Gocar-Carpooling-System/assets/69421772/220933c2-6ad4-437c-9d77-b840e25b723d)
